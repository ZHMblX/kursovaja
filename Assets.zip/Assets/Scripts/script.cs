﻿using System.Collections;
using System.Collections.Generic;
using System.Security.Cryptography;
using System.Threading;
using UnityEngine;

public class script : MonoBehaviour
{
    
    void Start()
    {
       
    }

    private float sp = 10;
    private void Update()
    {
        if (Input.GetKey(KeyCode.D))
         transform.Translate(Vector2.left * sp * Time.deltaTime);

        if (Input.GetKey(KeyCode.A))
            transform.Translate(Vector2.right * sp * Time.deltaTime);

        transform.Translate(Vector2.left * Input.GetAxis("Horizontal") * sp * Time.deltaTime);

        Vector2 position = transform.position;

        position.x = Mathf.Clamp(position.x, -15f, 15f);

        transform.position = position;
    }
}
