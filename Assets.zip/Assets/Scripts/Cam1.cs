﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Cam1 : MonoBehaviour
{
    [SerializeField]
    private Transform target;

    [SerializeField]
    [Range(1f, 12f)]
    private float interpolation = 1f;

    private void LateUpdate()
    {
        Followtarget();
    }
    private void Followtarget()
    {
        transform.position = Vector3.Lerp(transform.position, new Vector3(transform.position.x, target.position.y, transform.position.z), interpolation * Time.deltaTime);
    }
}