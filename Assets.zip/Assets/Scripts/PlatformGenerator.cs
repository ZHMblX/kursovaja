﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Collections.Specialized;
using UnityEngine;

public class PlatformGenerator : MonoBehaviour
{
    public GameObject platform;
    //public Transform generationPoint;
    //public float distanseBetween;
    //public GameObject button;

    //float PlatformWidth;

    //public Transform spawnZone;
    // public GameObject objToSpawn;

    //float minX;
    //float maxX;

    //float minY;
    //float maxY;

    void Start()
    {
        //minX = spawnZone.position.x + spawnZone.localScale.x / 2;
        //maxX = spawnZone.position.x - spawnZone.localScale.x / 2;

        //minY = spawnZone.position.y + spawnZone.localScale.y / 2;
        //maxY = spawnZone.position.y - spawnZone.localScale.y / 2;

        //PlatformWidth = platform.GetComponent<BoxCollider2D>().size.y;
        //PlatformWidth = platform.GetComponent<BoxCollider2D>().size.x;

        Vector3 SpawnPosition = new Vector3();

        for (int i=0; i<10; i++) ;
        {
            SpawnPosition.x = UnityEngine.Random.Range(-10f, 10f);
            SpawnPosition.y += UnityEngine.Random.Range(-17f, -8f);
            Instantiate(platform, SpawnPosition, Quaternion.identity);
        }
        for (int i=0; i<10; i++) ;
        {
            SpawnPosition.x = UnityEngine.Random.Range(-10f, 10f);
            SpawnPosition.y += UnityEngine.Random.Range(-17f, -8f);
            Instantiate(platform, SpawnPosition, Quaternion.identity);
        }
        for (int i=0; i<10; i++) ;
        {
            SpawnPosition.x = UnityEngine.Random.Range(-10f, 10f);
            SpawnPosition.y += UnityEngine.Random.Range(-17f, -7f);
            Instantiate(platform, SpawnPosition, Quaternion.identity);
        }
        for (int i=0; i<10; i++) ;
        {
            SpawnPosition.x = UnityEngine.Random.Range(-10f, 10f);
            SpawnPosition.y += UnityEngine.Random.Range(-17f, -7f);
            Instantiate(platform, SpawnPosition, Quaternion.identity);
        }
    }
}