﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Security.Cryptography;
using UnityEngine;

public class Platform : MonoBehaviour
{
    
    public void onCollisionExit2D(Collision platform)
    {
        if (platform.collider.name == "DestroyPoint")
        {
            float randomX = UnityEngine.Random.Range(-10f, 10f);
            float randomY = UnityEngine.Random.Range(transform.position.y -17f, transform.position.y -7f);

            transform.position = new Vector3(randomX, randomY, 0);
        }
        if (platform.collider.name == "DestroyPoint")
        {
            float randomX = UnityEngine.Random.Range(-10f, 10f);
            float randomY = UnityEngine.Random.Range(transform.position.y - 17f, transform.position.y - 7f);

            transform.position = new Vector3(randomX, randomY, 0);
        }
        if (platform.collider.name == "DestroyPoint")
        {
            float randomX = UnityEngine.Random.Range(-10f, 10f);
            float randomY = UnityEngine.Random.Range(transform.position.y - 17f, transform.position.y - 7f);

            transform.position = new Vector3(randomX, randomY, 0);
        }
        if (platform.collider.name == "DestroyPoint")
        {
            float randomX = UnityEngine.Random.Range(-10f, 10f);
            float randomY = UnityEngine.Random.Range(transform.position.y - 17f, transform.position.y - 7f);

            transform.position = new Vector3(randomX, randomY, 0);
        }
    }
}